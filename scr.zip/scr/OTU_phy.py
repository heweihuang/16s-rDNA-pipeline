import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import argparse
import os
import sys
from scipy.spatial.distance import pdist, squareform
import matplotlib.patches as mpatches

# 设置中文字体（如果需要显示中文）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial']
plt.rcParams['axes.unicode_minus'] = False

def load_data(input_file):
    """加载数据文件"""
    print(f"正在加载数据文件: {input_file}")
    
    # 读取文件，跳过注释行
    with open(input_file, 'r') as f:
        lines = f.readlines()
    
    # 找到第一个不以#开头的行作为表头
    header_line = None
    for i, line in enumerate(lines):
        if not line.startswith('#'):
            header_line = i
            break
    
    if header_line is None:
        raise ValueError("未找到表头行")
    
    # 读取数据
    df = pd.read_csv(input_file, sep='\t', skiprows=header_line-1)
    
    print(f"数据加载完成，共 {len(df)} 行，{len(df.columns)} 列")
    print(f"列名: {list(df.columns)}")
    
    return df

def extract_kingdom_phylum_info(consensus_lineage):
    """从Consensus Lineage中提取界和门水平信息"""
    if pd.isna(consensus_lineage):
        return "Unclassified"
    
    # 分割分类信息
    parts = consensus_lineage.split('; ')
    
    # 初始化界和门信息
    kingdom = ""
    phylum = ""
    
    # 查找界水平信息 (k__开头)
    for part in parts:
        if part.startswith('k__'):
            kingdom = part.strip()
            break
    
    # 查找门水平信息 (p__开头)
    for part in parts:
        if part.startswith('p__'):
            phylum = part.strip()
            break
    
    # 组合界和门信息
    if kingdom and phylum:
        return f"{kingdom}; {phylum}"
    elif kingdom:
        return f"{kingdom}; p__Unclassified"
    elif phylum:
        return f"k__Unclassified; {phylum}"
    else:
        return "k__Unclassified; p__Unclassified"

def extract_phylum_for_display(kingdom_phylum_str):
    """从界门信息中提取门信息用于显示（图中使用）"""
    if pd.isna(kingdom_phylum_str) or kingdom_phylum_str == "Unclassified":
        return "Unclassified"
    
    parts = kingdom_phylum_str.split('; ')
    for part in parts:
        if part.startswith('p__'):
            # 去掉p__前缀用于显示
            phylum = part[3:].strip()
            return phylum if phylum else "Unclassified"
    
    return "Unclassified"

def calculate_kingdom_phylum_percentages(df, sample_columns):
    """计算各样品在界门水平的百分比"""
    print("正在计算界门水平百分比...")
    
    # 提取界门信息
    df['Kingdom_Phylum'] = df['Consensus Lineage'].apply(extract_kingdom_phylum_info)
    
    # 按界门分组并汇总各样品计数
    kingdom_phylum_counts = df.groupby('Kingdom_Phylum')[sample_columns].sum()
    
    # 计算每个样品的总计数
    sample_totals = kingdom_phylum_counts.sum(axis=0)
    
    # 计算百分比
    kingdom_phylum_percentages = kingdom_phylum_counts.div(sample_totals) * 100
    
    # 按丰度排序（按所有样品的平均丰度）
    kingdom_phylum_percentages['Mean'] = kingdom_phylum_percentages.mean(axis=1)
    kingdom_phylum_percentages = kingdom_phylum_percentages.sort_values('Mean', ascending=False)
    kingdom_phylum_percentages = kingdom_phylum_percentages.drop('Mean', axis=1)
    
    print(f"识别到 {len(kingdom_phylum_percentages)} 个界门组合")
    
    return kingdom_phylum_percentages

def save_results(kingdom_phylum_percentages, output_dir):
    """保存结果到文件"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 保存百分比结果
    output_file = os.path.join(output_dir, "kingdom_phylum_percentages.txt")
    kingdom_phylum_percentages.to_csv(output_file, sep='\t', float_format='%.4f')
    print(f"界门水平百分比已保存到: {output_file}")
    
    return output_file

def plot_stacked_bar(kingdom_phylum_percentages, output_dir):
    """绘制堆叠直方图（堆叠柱状图）"""
    print("正在绘制堆叠直方图...")
    
    # 准备数据 - 取前N个最丰富的界门组合，其他的归为"Others"
    top_n = 15
    if len(kingdom_phylum_percentages) > top_n:
        top_taxa = kingdom_phylum_percentages.head(top_n)
        others = kingdom_phylum_percentages.iloc[top_n:].sum()
        others.name = 'Others'
        plot_data = pd.concat([top_taxa, pd.DataFrame(others).T])
    else:
        plot_data = kingdom_phylum_percentages
    
    # 提取门信息用于图例显示
    plot_data_display = plot_data.copy()
    plot_data_display.index = [extract_phylum_for_display(idx) for idx in plot_data.index]
    
    # 设置颜色
    colors = plt.cm.tab20c(np.linspace(0, 1, len(plot_data)))
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # 绘制堆叠柱状图
    bottom = np.zeros(len(plot_data.columns))
    for i, (taxon, row) in enumerate(plot_data.iterrows()):
        display_name = extract_phylum_for_display(taxon)
        ax.bar(plot_data.columns, row.values, bottom=bottom, 
               label=display_name, color=colors[i], edgecolor='white')
        bottom += row.values
    
    # 设置图形属性
    ax.set_xlabel('样品', fontsize=12)
    ax.set_ylabel('相对丰度 (%)', fontsize=12)
    ax.set_title('样品在门水平的相对丰度分布', fontsize=14, fontweight='bold')
    ax.set_ylim(0, 100)
    
    # 添加图例
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0., 
              fontsize=10, title='门')
    
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    # 保存图形
    output_file = os.path.join(output_dir, "phylum_stacked_bar.png")
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"堆叠直方图已保存到: {output_file}")
    
    # 同时保存用于绘图的数据（包含界门完整信息）
    plot_data_with_full_names = plot_data.copy()
    plot_data_with_full_names['Display_Name'] = plot_data_display.index
    output_file_data = os.path.join(output_dir, "plot_data_for_stacked_bar.txt")
    plot_data_with_full_names.to_csv(output_file_data, sep='\t', float_format='%.4f')
    print(f"堆叠图数据已保存到: {output_file_data}")

def plot_pca(df, sample_columns, output_dir):
    """绘制PCA图"""
    print("正在绘制PCA图...")
    
    # 提取样品数据
    sample_data = df[sample_columns].T  # 转置，使样品为行
    
    # 标准化数据
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(sample_data)
    
    # 执行PCA
    pca = PCA(n_components=2)
    pca_result = pca.fit_transform(scaled_data)
    
    # 创建PCA结果DataFrame
    pca_df = pd.DataFrame(data=pca_result, columns=['PC1', 'PC2'])
    pca_df['Sample'] = sample_columns
    
    # 计算方差解释比例
    explained_var = pca.explained_variance_ratio_ * 100
    
    # 绘制PCA图
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # 绘制散点
    scatter = ax.scatter(pca_df['PC1'], pca_df['PC2'], s=100, alpha=0.8)
    
    # 添加样品标签
    for i, sample in enumerate(sample_columns):
        ax.annotate(sample, (pca_df['PC1'].iloc[i], pca_df['PC2'].iloc[i]), 
                   xytext=(5, 5), textcoords='offset points', fontsize=9)
    
    # 设置图形属性
    ax.set_xlabel(f'PC1 ({explained_var[0]:.2f}%)', fontsize=12)
    ax.set_ylabel(f'PC2 ({explained_var[1]:.2f}%)', fontsize=12)
    ax.set_title('样品PCA分析', fontsize=14, fontweight='bold')
    ax.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    
    # 保存图形
    output_file = os.path.join(output_dir, "pca_plot.png")
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    # 保存PCA数据
    pca_output_file = os.path.join(output_dir, "pca_results.txt")
    pca_df.to_csv(pca_output_file, sep='\t', float_format='%.4f', index=False)
    print(f"PCA数据已保存到: {pca_output_file}")
    print(f"PCA图已保存到: {output_file}")

def plot_pcoa_simple(df, sample_columns, output_dir):
    """使用scipy绘制PCoA图"""
    print("正在绘制PCoA图（使用scipy实现）...")
    
    try:
        # 计算每个样品的相对丰度
        sample_data = df[sample_columns].T
        rel_abundance = sample_data.div(sample_data.sum(axis=1), axis=0)
        
        # 使用scipy的pdist计算Bray-Curtis距离
        from scipy.spatial.distance import pdist, squareform
        
        # 计算Bray-Curtis距离矩阵
        dist_matrix = pdist(rel_abundance.values, metric='braycurtis')
        dist_matrix = squareform(dist_matrix)
        
        # 执行PCoA
        n = dist_matrix.shape[0]
        J = np.eye(n) - np.ones((n, n)) / n
        B = -0.5 * J.dot(dist_matrix**2).dot(J)
        
        # 特征值分解
        eigvals, eigvecs = np.linalg.eigh(B)  # 使用eigh确保实特征值
        
        # 按特征值排序
        idx = eigvals.argsort()[::-1]
        eigvals = eigvals[idx]
        eigvecs = eigvecs[:, idx]
        
        # 取前两个主坐标
        coords = eigvecs[:, :2] * np.sqrt(np.abs(eigvals[:2]))
        
        # 计算解释比例
        explained_var = np.abs(eigvals[:2]) / np.abs(eigvals).sum() * 100
        
        # 绘制PCoA图
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # 绘制散点
        colors = plt.cm.tab10(np.linspace(0, 1, n))
        scatter = ax.scatter(coords[:, 0], coords[:, 1], s=100, alpha=0.8, c=colors)
        
        # 添加样品标签
        for i, sample in enumerate(sample_columns):
            ax.annotate(sample, (coords[i, 0], coords[i, 1]), 
                       xytext=(5, 5), textcoords='offset points', fontsize=9)
        
        # 设置图形属性
        ax.set_xlabel(f'PCo1 ({explained_var[0]:.2f}%)', fontsize=12)
        ax.set_ylabel(f'PCo2 ({explained_var[1]:.2f}%)', fontsize=12)
        ax.set_title('样品PCoA分析 (Bray-Curtis距离)', fontsize=14, fontweight='bold')
        ax.grid(True, linestyle='--', alpha=0.7)
        
        plt.tight_layout()
        
        # 保存图形
        output_file = os.path.join(output_dir, "pcoa_plot.png")
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        plt.close()
        
        # 保存PCoA数据
        pcoa_df = pd.DataFrame({
            'Sample': sample_columns,
            'PCo1': coords[:, 0],
            'PCo2': coords[:, 1]
        })
        pcoa_output_file = os.path.join(output_dir, "pcoa_results.txt")
        pcoa_df.to_csv(pcoa_output_file, sep='\t', float_format='%.4f', index=False)
        
        # 保存距离矩阵
        dist_df = pd.DataFrame(dist_matrix, index=sample_columns, columns=sample_columns)
        dist_output_file = os.path.join(output_dir, "bray_curtis_distance_matrix.txt")
        dist_df.to_csv(dist_output_file, sep='\t', float_format='%.4f')
        
        print(f"PCoA数据已保存到: {pcoa_output_file}")
        print(f"距离矩阵已保存到: {dist_output_file}")
        print(f"PCoA图已保存到: {output_file}")
        
    except Exception as e:
        print(f"PCoA图绘制失败: {e}")
        print("将跳过PCoA图的生成")

def plot_rank_abundance(df, sample_columns, output_dir):
    """绘制Rank-Abundance图"""
    print("正在绘制Rank-Abundance图...")
    
    # 计算每个样品的相对丰度
    sample_data = df[sample_columns].T
    rel_abundance = sample_data.div(sample_data.sum(axis=1), axis=0)
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 为每个样品绘制Rank-Abundance曲线
    colors = plt.cm.tab10(np.linspace(0, 1, len(sample_columns)))
    
    # 保存每个样品的排序数据
    rank_data = {}
    
    for i, sample in enumerate(sample_columns):
        # 对相对丰度进行排序（降序）
        sorted_abundance = np.sort(rel_abundance.loc[sample].values)[::-1]
        
        # 计算累积排名
        ranks = np.arange(1, len(sorted_abundance) + 1)
        
        # 保存数据
        rank_data[sample] = {
            'ranks': ranks,
            'abundance': sorted_abundance
        }
        
        # 绘制曲线（使用对数坐标）
        ax.plot(ranks, sorted_abundance, 'o-', linewidth=2, markersize=4,
                color=colors[i], label=sample, alpha=0.8)
    
    # 设置图形属性
    ax.set_xlabel('物种排序 (Rank)', fontsize=12)
    ax.set_ylabel('相对丰度 (log10)', fontsize=12)
    ax.set_title('Rank-Abundance曲线', fontsize=14, fontweight='bold')
    ax.set_yscale('log')
    ax.grid(True, linestyle='--', alpha=0.7)
    ax.legend(fontsize=10)
    
    plt.tight_layout()
    
    # 保存图形
    output_file = os.path.join(output_dir, "rank_abundance_plot.png")
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    # 保存排名数据
    max_len = max(len(data['ranks']) for data in rank_data.values())
    
    # 创建DataFrame保存所有数据
    rank_df_dict = {'Rank': np.arange(1, max_len + 1)}
    for sample, data in rank_data.items():
        ranks = data['ranks']
        abundance = data['abundance']
        
        # 扩展数组到最大长度，用NaN填充
        if len(ranks) < max_len:
            extended_abundance = np.full(max_len, np.nan)
            extended_abundance[:len(ranks)] = abundance
            rank_df_dict[sample] = extended_abundance
        else:
            rank_df_dict[sample] = abundance
    
    rank_df = pd.DataFrame(rank_df_dict)
    rank_output_file = os.path.join(output_dir, "rank_abundance_data.txt")
    rank_df.to_csv(rank_output_file, sep='\t', float_format='%.6f', index=False)
    
    print(f"Rank-Abundance数据已保存到: {rank_output_file}")
    print(f"Rank-Abundance图已保存到: {output_file}")

def main():
    # 设置命令行参数
    parser = argparse.ArgumentParser(description='16S rDNA界门水平统计与可视化')
    parser.add_argument('-i', '--input', required=True, help='输入文件路径')
    parser.add_argument('-o', '--output', default='output_results', help='输出目录路径')
    parser.add_argument('--top_n', type=int, default=15, help='堆叠图中显示的前N个分类单元（默认: 15）')
    
    args = parser.parse_args()
    
    # 加载数据
    df = load_data(args.input)
    
    # 识别样品列（在#OTU ID和Consensus Lineage之间的列）
    columns = list(df.columns)
    start_idx = columns.index('#OTU ID') + 1 if '#OTU ID' in columns else 0
    end_idx = columns.index('Consensus Lineage') if 'Consensus Lineage' in columns else len(columns)
    
    sample_columns = columns[start_idx:end_idx]
    print(f"识别到 {len(sample_columns)} 个样品: {sample_columns}")
    
    # 计算界门水平百分比
    kingdom_phylum_percentages = calculate_kingdom_phylum_percentages(df, sample_columns)
    
    # 保存结果
    result_file = save_results(kingdom_phylum_percentages, args.output)
    
    # 绘制图表
    plot_stacked_bar(kingdom_phylum_percentages, args.output)
    plot_pca(df, sample_columns, args.output)
    plot_pcoa_simple(df, sample_columns, args.output)
    plot_rank_abundance(df, sample_columns, args.output)
    
    # 生成汇总报告
    print("\n" + "="*60)
    print("分析完成！汇总报告：")
    print("="*60)
    print(f"1. 界门水平百分比表格: {args.output}/kingdom_phylum_percentages.txt")
    print(f"2. 堆叠柱状图: {args.output}/phylum_stacked_bar.png")
    print(f"3. 堆叠图数据: {args.output}/plot_data_for_stacked_bar.txt")
    print(f"4. PCA分析图: {args.output}/pca_plot.png")
    print(f"5. PCA结果数据: {args.output}/pca_results.txt")
    print(f"6. PCoA分析图: {args.output}/pcoa_plot.png")
    print(f"7. PCoA结果数据: {args.output}/pcoa_results.txt")
    print(f"8. Bray-Curtis距离矩阵: {args.output}/bray_curtis_distance_matrix.txt")
    print(f"9. Rank-Abundance曲线图: {args.output}/rank_abundance_plot.png")
    print(f"10. Rank-Abundance数据: {args.output}/rank_abundance_data.txt")
    print("="*60)
    print(f"所有结果已保存到目录: {args.output}")
    print("="*60)

if __name__ == "__main__":
    main()
