import sys
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import squareform
import argparse

def read_distance_matrix(file_path):
    """
    读取距离矩阵文件。
    格式：第一行和第一列都是样本名称，对角线上方或下方为距离值。
    """
    with open(file_path, 'r') as f:
        lines = [line.strip() for line in f.readlines()]
    
    # 第一行是样本名称（包含第一个空单元格）
    header = lines[0].split('\t')
    samples = header[1:]  # 跳过第一个空单元格或第一个样本名
    
    # 读取距离数据
    data = []
    for line in lines[1:]:
        parts = line.split('\t')
        # 第一列是样本名称，跳过它
        row_data = parts[1:]
        data.append(list(map(float, row_data)))
    
    # 转换为numpy数组
    dist_matrix = np.array(data)
    
    return samples, dist_matrix

def upgma_clustering_and_plot(dist_matrix, samples, output_file='upgma_dendrogram.png'):
    """
    执行UPGMA聚类并绘制树状图。
    """
    # 检查距离矩阵是否是对称的
    if not np.allclose(dist_matrix, dist_matrix.T):
        print("Warning: Distance matrix is not perfectly symmetric. Using lower triangle.")
    
    # 将完整的距离矩阵转换为压缩距离向量（上三角）
    # squareform期望对称矩阵，对角线为0
    condensed_dist = squareform(dist_matrix, checks=False)
    
    # 使用UPGMA方法进行层次聚类
    # method='average' 对应UPGMA
    linkage_matrix = linkage(condensed_dist, method='average')
    
    # 绘制树状图
    plt.figure(figsize=(10, 7))
    dendrogram(linkage_matrix, labels=samples, leaf_rotation=90, leaf_font_size=10)
    plt.title('UPGMA Clustering Dendrogram (Unweighted UniFrac)')
    plt.xlabel('Samples')
    plt.ylabel('Distance')
    plt.tight_layout()
    
    # 保存图像
    plt.savefig(output_file, dpi=300)
    plt.show()
    
    print(f"Dendrogram saved to {output_file}")
    return linkage_matrix

def main():
    parser = argparse.ArgumentParser(description='UPGMA clustering analysis from distance matrix')
    parser.add_argument('-i', '--input', required=True, help='Input distance matrix file (e.g., unweighted_unifrac_dm.txt)')
    parser.add_argument('-o', '--output', default='upgma_dendrogram.png', help='Output dendrogram image file (default: upgma_dendrogram.png)')
    args = parser.parse_args()
    
    # 读取距离矩阵
    samples, dist_matrix = read_distance_matrix(args.input)
    print(f"Loaded {len(samples)} samples: {samples}")
    print("Distance matrix shape:", dist_matrix.shape)
    print("First few rows of distance matrix:")
    print(dist_matrix[:min(5, len(samples)), :min(5, len(samples))])
    
    # 执行UPGMA聚类并绘图
    linkage_matrix = upgma_clustering_and_plot(dist_matrix, samples, args.output)
    
    # 可选：保存linkage矩阵为文本文件
    np.savetxt('linkage_matrix.txt', linkage_matrix, delimiter='\t', fmt='%.6f')
    print("Linkage matrix saved to linkage_matrix.txt")

if __name__ == '__main__':
    main()
