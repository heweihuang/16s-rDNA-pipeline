import sys
import pandas as pd
import numpy as np
from skbio import TreeNode
from skbio.diversity.alpha import chao1, shannon, simpson, goods_coverage, faith_pd
import warnings

# 抑制可能的警告
warnings.filterwarnings('ignore')

def read_otu_table(otu_table_path):
    """
    读取OTU表格，处理可能的格式问题
    """
    try:
        # 尝试读取文件，识别注释行和表头
        with open(otu_table_path, 'r') as f:
            lines = f.readlines()
        
        # 找到真正的表头行（不以#开头且包含样品名的行）
        header_line = None
        data_start = 0
        
        for i, line in enumerate(lines):
            if line.startswith('#OTU ID') or ('SRR' in line and 'OTU' not in line):
                # 这是表头行
                header_line = line.strip()
                data_start = i + 1
                break
            elif not line.startswith('#') and i > 0:  # 不是注释行且不是第一行
                # 这可能是表头行
                header_line = line.strip()
                data_start = i + 1
                break
        
        if header_line is None:
            # 如果没有找到合适的表头，使用第一行
            header_line = lines[0].strip()
            data_start = 1
        
        # 解析表头
        headers = header_line.split('\t')
        
        # 读取数据
        data_lines = []
        for i in range(data_start, len(lines)):
            if lines[i].strip() and not lines[i].startswith('#'):
                data_lines.append(lines[i])
        
        # 创建DataFrame
        if len(headers) > 1 and headers[0] == 'OTU ID':
            # 标准格式
            df = pd.read_csv(otu_table_path, sep='\t', comment='#', skiprows=data_start-1)
        else:
            # 非标准格式，尝试重新构建
            data = [line.strip().split('\t') for line in data_lines]
            df = pd.DataFrame(data)
            
            # 如果第一列是数字且没有列名，添加列名
            if df.shape[1] == len(headers):
                df.columns = headers
            else:
                # 使用默认列名
                df.columns = ['OTU_ID'] + [f'Sample_{i}' for i in range(df.shape[1]-1)]
        
        # 设置OTU ID为索引
        if 'OTU ID' in df.columns:
            df = df.set_index('OTU ID')
        elif 'OTU_ID' in df.columns:
            df = df.set_index('OTU_ID')
        elif df.columns[0] == '#OTU ID':
            df = df.rename(columns={'#OTU ID': 'OTU_ID'})
            df = df.set_index('OTU_ID')
        else:
            # 假设第一列是OTU ID
            df = df.rename(columns={df.columns[0]: 'OTU_ID'})
            df = df.set_index('OTU_ID')
        
        # 确保数据是数值类型
        df = df.apply(pd.to_numeric, errors='coerce')
        
        # 打印信息用于调试
        print(f"读取OTU表格成功:")
        print(f"  - OTU数量: {df.shape[0]}")
        print(f"  - 样品数量: {df.shape[1]}")
        print(f"  - 样品名: {list(df.columns)}")
        print(f"  - 前5个OTU ID: {list(df.index[:5])}")
        
        return df
    
    except Exception as e:
        print(f"读取OTU表格时出错: {e}")
        raise

def calculate_alpha_diversity(otu_table_path, tree_path, output_path):
    """
    计算 OTU 表格中各样品的 Alpha 多样性指标，包括 PD_whole_tree。
    """
    # 读取 OTU 表格
    print("正在读取OTU表格...")
    df = read_otu_table(otu_table_path)
    
    # 确保没有NaN值（用0填充）
    df = df.fillna(0)
    
    # 读取系统发育树
    tree = None
    if tree_path.lower() != 'none':
        try:
            print(f"正在读取系统发育树: {tree_path}")
            tree = TreeNode.read(tree_path)
            print(f"树读取成功，包含 {len(list(tree.tips()))} 个tips")
            
            # 检查OTU ID匹配
            tree_tips = [tip.name for tip in tree.tips() if tip.name]
            otu_ids = [str(idx) for idx in df.index]
            
            # 查找匹配的OTU ID
            matched_otus = [otu for otu in otu_ids if otu in tree_tips]
            match_rate = len(matched_otus) / len(otu_ids) * 100
            
            print(f"OTU在树中的匹配情况:")
            print(f"  - 树中tips数量: {len(tree_tips)}")
            print(f"  - OTU表格中OTU数量: {len(otu_ids)}")
            print(f"  - 匹配的OTU数量: {len(matched_otus)}")
            print(f"  - 匹配率: {match_rate:.2f}%")
            
            if match_rate < 50:
                print("警告: OTU在树中的匹配率较低，PD_whole_tree计算结果可能不准确")
                print("建议: 检查OTU ID格式是否与树中标签一致")
            
        except Exception as e:
            print(f"读取系统发育树失败: {e}")
            print("将跳过 PD_whole_tree 的计算")
            tree = None
    else:
        print("未提供系统发育树，跳过PD_whole_tree计算")
    
    # 计算每个样品的 Alpha 多样性指标
    print("\n正在计算Alpha多样性指标...")
    results = []
    
    for sample in df.columns:
        print(f"处理样品: {sample}")
        counts = df[sample].values
        otu_ids = [str(idx) for idx in df.index]
        
        # 创建计数字典（只包含非零计数）
        counts_dict = {}
        for otu_id, count in zip(otu_ids, counts):
            if count > 0:
                counts_dict[otu_id] = float(count)
        
        if len(counts_dict) == 0:
            print(f"警告: 样品 {sample} 所有计数为0，跳过计算")
            continue
        
        # 提取非零计数用于其他计算
        non_zero_counts = counts[counts > 0]
        
        try:
            # Chao1
            chao1_val = chao1(non_zero_counts)
        except Exception as e:
            print(f"样品 {sample} Chao1计算失败: {e}")
            chao1_val = np.nan
        
        try:
            # Shannon（以 e 为底）
            shannon_val = shannon(non_zero_counts, base=np.e)
        except Exception as e:
            print(f"样品 {sample} Shannon计算失败: {e}")
            shannon_val = np.nan
        
        try:
            # Simpson
            simpson_val = simpson(non_zero_counts)
        except Exception as e:
            print(f"样品 {sample} Simpson计算失败: {e}")
            simpson_val = np.nan
        
        # Observed species（即非零 OTU 数量）
        observed_species_val = len(non_zero_counts)
        
        try:
            # Good's coverage
            goods_cov_val = goods_coverage(non_zero_counts)
        except Exception as e:
            print(f"样品 {sample} Good's coverage计算失败: {e}")
            goods_cov_val = np.nan
        
        # PD_whole_tree (Faith's PD)
        pd_whole_tree_val = np.nan
        if tree is not None and len(counts_dict) > 0:
            try:
                # 只使用树中存在的OTU
                filtered_counts = {k: v for k, v in counts_dict.items() if k in [tip.name for tip in tree.tips()]}
                if len(filtered_counts) > 0:
                    pd_whole_tree_val = faith_pd(filtered_counts, tree)
                    print(f"  样品 {sample} PD_whole_tree: {pd_whole_tree_val:.4f}")
                else:
                    print(f"  样品 {sample} 无匹配的OTU在树中，PD_whole_tree设为NaN")
            except Exception as e:
                print(f"样品 {sample} PD_whole_tree计算失败: {e}")
        
        results.append({
            'Sample': sample,
            'Chao1': chao1_val,
            'PD_whole_tree': pd_whole_tree_val,
            'Shannon': shannon_val,
            'Simpson': simpson_val,
            'observed_species': observed_species_val,
            'goods_coverage': goods_cov_val
        })
    
    # 转换为 DataFrame
    result_df = pd.DataFrame(results)
    
    # 保存结果
    print(f"\n保存结果到: {output_path}")
    result_df.to_csv(output_path, index=False, sep='\t', float_format='%.6f')
    
    # 打印摘要
    print("\nAlpha多样性计算结果摘要:")
    print("=" * 80)
    print(result_df.to_string(index=False))
    print("=" * 80)
    
    # 保存统计摘要
    summary_path = output_path.replace('.txt', '_summary.txt').replace('.tsv', '_summary.tsv')
    with open(summary_path, 'w') as f:
        f.write("Alpha多样性统计摘要\n")
        f.write("=" * 50 + "\n")
        f.write(f"样品数量: {len(result_df)}\n")
        f.write(f"计算时间: {pd.Timestamp.now()}\n\n")
        
        for col in ['Chao1', 'Shannon', 'Simpson', 'observed_species', 'goods_coverage']:
            if col in result_df.columns:
                f.write(f"{col}:\n")
                f.write(f"  平均值: {result_df[col].mean():.4f}\n")
                f.write(f"  标准差: {result_df[col].std():.4f}\n")
                f.write(f"  最小值: {result_df[col].min():.4f}\n")
                f.write(f"  最大值: {result_df[col].max():.4f}\n\n")
    
    print(f"统计摘要已保存到: {summary_path}")
    
    return result_df

def main():
    if len(sys.argv) < 3 or len(sys.argv) > 4:
        print("用法: python alpha_diversity.py <输入OTU表格> <系统发育树文件> [输出文件]")
        print("或:   python alpha_diversity.py <输入OTU表格> none [输出文件] (无树文件)")
        print("\n示例:")
        print("  1. 有树文件: python alpha_diversity.py output.txt tree.nwk alpha_results.txt")
        print("  2. 无树文件: python alpha_diversity.py output.txt none alpha_results.txt")
        print("\n默认输出文件: alpha_diversity_results.txt")
        sys.exit(1)
    
    input_file = sys.argv[1]
    tree_file = sys.argv[2]
    
    if len(sys.argv) == 4:
        output_file = sys.argv[3]
    else:
        output_file = "alpha_diversity_results.txt"
    
    try:
        results = calculate_alpha_diversity(input_file, tree_file, output_file)
        print(f"\n计算完成! 结果已保存到: {output_file}")
    except Exception as e:
        print(f"计算过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
