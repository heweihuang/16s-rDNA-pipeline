# 加载必要的包
library(VennDiagram)
library(grid)

# 完全禁用X11
Sys.setenv("DISPLAY" = ":0")
options(bitmapType = 'cairo')

# 设置输入参数
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 3) {
  stop("请提供三个参数：输入文件路径、输出图片路径、样本列名（逗号分隔）")
}

input_file <- args[1]
output_file <- args[2]
sampleCol_str <- args[3]

# 将逗号分隔的样本列名转换为向量
sampleCol <- unlist(strsplit(sampleCol_str, ","))

cat("正在读取数据...\n")
rt <- read.table(input_file, sep="\t", header=TRUE, skip=1, 
                 row.names=1, comment.char = "", check.names = FALSE)

cat("正在处理样本数据...\n")
list1 <- list()
for(i in sampleCol) {
  if(!i %in% colnames(rt)) {
    stop(paste("列名", i, "在数据中不存在"))
  }
  rt1 <- rt[rt[, i] != 0, ]
  list1[[i]] <- rownames(rt1)
  cat(paste("样本", i, "有", length(list1[[i]]), "个非零OTU\n"))
}

cat("正在生成韦恩图...\n")

# 确保输出目录存在
output_dir <- dirname(output_file)
if (!dir.exists(output_dir) && output_dir != ".") {
  dir.create(output_dir, recursive = TRUE)
}

# 强制使用PDF格式（在服务器上更稳定）
if (!grepl("\\.pdf$", output_file, ignore.case = TRUE)) {
  output_file <- sub("\\.[a-zA-Z]+$", ".pdf", output_file)
}

# 生成韦恩图 - 使用PDF设备
pdf(file = output_file, width = 10, height = 10)
venn.plot <- venn.diagram(
  x = list1,
  filename = NULL,  # 不直接写入文件
  fill = rainbow(length(sampleCol)),
  alpha = 0.5,
  cex = 1.5,
  cat.cex = 1.2,
  cat.fontface = "bold",
  margin = 0.1,
  disable.logging = TRUE
)
grid.draw(venn.plot)
dev.off()

cat(paste("韦恩图已成功生成:", output_file, "\n"))
cat("如果需要PNG格式，可以使用以下命令转换：\n")
cat(paste("convert", output_file, sub("\\.pdf$", ".png", output_file), "\n"))
