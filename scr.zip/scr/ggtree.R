#setwd("C:/Users/DELL/Desktop/tree")
library("ggplot2")
library("ggtree")
library('gplots')
library("colorspace")

cls=list()
rt=read.table("table.from_0.001_fraction.txt",sep="\t",header=T,skip=1,row.names=1,comment.char = "")
# 切割门物种，将out传进门的容器列表中
for(i in 1:nrow(rt)){
 otu=rownames(rt[i,])
 phylum=strsplit(as.character(rt$taxonomy[i]),"\\; |p\\_\\_")[[1]][3]
 cls[[phylum]]=c(cls[[phylum]], otu)
}
# 门的名字和长度
phylumNames=names(cls)
phylumNum=length(phylumNames)

# 读取树文件，确定，按门的名字进行分组otu
tree <- read.tree("rep_set_0.001_fraction.tre")
tree <- groupOTU(tree, cls)

# 去除NewReference，只显示OTU号
pdf(file="circosTree.pdf")
ggtree(tree, layout="fan", ladderize = FALSE, branch.length="none", aes(color=group)) +
       scale_color_manual(values=c(rainbow_hcl(phylumNum+1)), breaks=1:phylumNum, labels=phylumNames ) + theme(legend.position="right") +
       geom_text(aes(label=paste("                ",gsub("\\d+\\.\\d+|New\\.|Reference|CleanUp\\.","",label),sep=""), angle=angle+90), size=2.2)
dev.off()

pdf(file="heatmapTree.pdf",width=15,height=18)
p <- ggtree(tree, ladderize = FALSE, branch.length="none", aes(color=group)) +
       scale_color_manual(values=c(rainbow_hcl(phylumNum+1)), breaks=1:phylumNum, labels=phylumNames ) + theme(legend.position="left") +
       geom_text(aes(label=paste("    ",gsub("\\d+\\.\\d+|New\\.|Reference|CleanUp\\.","",label),sep="")), size=2.2)

# 最后一列为tax，需要-1，取log值标准化，画热图。
#gplot(p, log(rt[,1:ncol(rt)-1]+1), font.size=4)
gplot(as.matrix(log(rt[,1:(ncol(rt)-1)] + 1)), font.size = 4)
dev.off()
