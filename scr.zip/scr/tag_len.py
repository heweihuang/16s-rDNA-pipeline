import argparse
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import Counter, defaultdict
from typing import Dict, List, Tuple
import sys

def read_fasta_file(fasta_file: str) -> Dict[str, str]:
    """
    读取FASTA文件并返回序列字典
    """
    sequences = {}
    current_id = None
    current_seq = []
    
    try:
        with open(fasta_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line.startswith('>'):
                    if current_id is not None:
                        sequences[current_id] = ''.join(current_seq)
                    current_id = line[1:].split()[0]  # 只取ID，忽略描述
                    current_seq = []
                else:
                    current_seq.append(line)
            
            # 添加最后一个序列
            if current_id is not None:
                sequences[current_id] = ''.join(current_seq)
                
    except FileNotFoundError:
        print(f"错误: 文件 '{fasta_file}' 未找到")
        sys.exit(1)
    except Exception as e:
        print(f"读取文件时出错: {e}")
        sys.exit(1)
    
    return sequences

def calculate_length_statistics(sequences: Dict[str, str]) -> Tuple[Dict, Dict]:
    """
    计算序列长度统计信息
    """
    lengths = [len(seq) for seq in sequences.values()]
    
    # 统计每个长度出现的次数
    length_counts = Counter(lengths)
    
    # 计算基本统计信息
    stats = {
        'total_sequences': len(lengths),
        'min_length': min(lengths),
        'max_length': max(lengths),
        'mean_length': np.mean(lengths),
        'median_length': np.median(lengths),
        'std_length': np.std(lengths),
        'total_bases': sum(lengths),
        'n50': calculate_n50(lengths) if lengths else 0
    }
    
    return stats, dict(sorted(length_counts.items()))

def calculate_n50(lengths: List[int]) -> int:
    """
    计算N50值
    """
    sorted_lengths = sorted(lengths, reverse=True)
    total_length = sum(lengths)
    half_length = total_length / 2
    
    cumulative_length = 0
    for length in sorted_lengths:
        cumulative_length += length
        if cumulative_length >= half_length:
            return length
    return 0

def create_length_table(stats: Dict, length_counts: Dict) -> pd.DataFrame:
    """
    创建长度统计表格
    """
    # 创建统计信息表格
    stats_df = pd.DataFrame([stats])
    
    # 创建长度分布表格
    length_df = pd.DataFrame(
        list(length_counts.items()),
        columns=['Sequence_Length', 'Count']
    )
    length_df['Percentage'] = (length_df['Count'] / length_df['Count'].sum() * 100).round(2)
    
    return stats_df, length_df

def create_bar_chart(length_counts: Dict, output_prefix: str):
    """
    创建序列长度分布的条形图
    """
    lengths = list(length_counts.keys())
    counts = list(length_counts.values())
    
    plt.figure(figsize=(12, 6))
    
    # 如果长度类别太多，使用直方图
    if len(lengths) > 50:
        plt.hist(
            np.repeat(lengths, counts),
            bins=min(50, len(set(lengths))),
            edgecolor='black',
            alpha=0.7
        )
        plt.xlabel('Sequence Length')
        plt.ylabel('Frequency')
        plt.title('Sequence Length Distribution Histogram')
    else:
        # 条形图
        bars = plt.bar(lengths, counts, edgecolor='black', alpha=0.7)
        plt.xlabel('Sequence Length')
        plt.ylabel('Number of Sequences')
        plt.title('Sequence Length Distribution Bar Chart')
        
        # 为条形图添加数值标签
        for bar in bars:
            height = bar.get_height()
            if height > max(counts) * 0.01:  # 只在足够高的条上显示标签
                plt.text(
                    bar.get_x() + bar.get_width()/2.,
                    height,
                    f'{int(height)}',
                    ha='center',
                    va='bottom',
                    fontsize=8
                )
    
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(f'{output_prefix}_length_distribution.png', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_prefix}_length_distribution.pdf', bbox_inches='tight')
    plt.close()

def main():
    # 设置命令行参数
    parser = argparse.ArgumentParser(
        description='统计FASTA文件中序列长度分布并生成图表',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python fasta_length_stats.py input.fasta
  python fasta_length_stats.py input.fasta -o results
  python fasta_length_stats.py input.fasta -o results --min_len 100 --max_len 10000
        """
    )
    
    parser.add_argument(
        'input_fasta',
        type=str,
        help='输入的FASTA文件路径'
    )
    
    parser.add_argument(
        '-o', '--output_prefix',
        type=str,
        default='fasta_stats',
        help='输出文件的前缀（默认: fasta_stats）'
    )
    
    parser.add_argument(
        '--min_len',
        type=int,
        default=None,
        help='过滤最小序列长度（可选）'
    )
    
    parser.add_argument(
        '--max_len',
        type=int,
        default=None,
        help='过滤最大序列长度（可选）'
    )
    
    parser.add_argument(
        '--format',
        type=str,
        choices=['csv', 'tsv', 'excel', 'all'],
        default='all',
        help='输出表格格式（默认: all）'
    )
    
    args = parser.parse_args()
    
    # 读取FASTA文件
    print(f"正在读取文件: {args.input_fasta}")
    sequences = read_fasta_file(args.input_fasta)
    print(f"读取到 {len(sequences)} 条序列")
    
    # 应用长度过滤
    if args.min_len is not None or args.max_len is not None:
        filtered_sequences = {}
        for seq_id, seq in sequences.items():
            seq_len = len(seq)
            if (args.min_len is None or seq_len >= args.min_len) and \
               (args.max_len is None or seq_len <= args.max_len):
                filtered_sequences[seq_id] = seq
        
        print(f"过滤后保留 {len(filtered_sequences)} 条序列")
        sequences = filtered_sequences
    
    # 计算统计信息
    stats, length_counts = calculate_length_statistics(sequences)
    
    # 打印基本统计信息
    print("\n" + "="*50)
    print("序列长度统计摘要:")
    print("="*50)
    print(f"总序列数: {stats['total_sequences']}")
    print(f"总碱基数: {stats['total_bases']:,}")
    print(f"最短序列: {stats['min_length']} bp")
    print(f"最长序列: {stats['max_length']} bp")
    print(f"平均长度: {stats['mean_length']:.2f} bp")
    print(f"中位长度: {stats['median_length']} bp")
    print(f"长度标准差: {stats['std_length']:.2f}")
    print(f"N50: {stats['n50']} bp")
    
    # 创建统计表格
    stats_df, length_df = create_length_table(stats, length_counts)
    
    # 保存统计表格
    output_files = []
    
    if args.format in ['csv', 'all']:
        stats_df.to_csv(f'{args.output_prefix}_statistics.csv', index=False)
        length_df.to_csv(f'{args.output_prefix}_length_distribution.csv', index=False)
        output_files.extend([
            f'{args.output_prefix}_statistics.csv',
            f'{args.output_prefix}_length_distribution.csv'
        ])
    
    if args.format in ['tsv', 'all']:
        stats_df.to_csv(f'{args.output_prefix}_statistics.tsv', sep='\t', index=False)
        length_df.to_csv(f'{args.output_prefix}_length_distribution.tsv', sep='\t', index=False)
        output_files.extend([
            f'{args.output_prefix}_statistics.tsv',
            f'{args.output_prefix}_length_distribution.tsv'
        ])
    
    if args.format in ['excel', 'all']:
        with pd.ExcelWriter(f'{args.output_prefix}_statistics.xlsx') as writer:
            stats_df.to_excel(writer, sheet_name='Summary', index=False)
            length_df.to_excel(writer, sheet_name='Length Distribution', index=False)
        output_files.append(f'{args.output_prefix}_statistics.xlsx')
    
    # 生成条形图
    create_bar_chart(length_counts, args.output_prefix)
    output_files.extend([
        f'{args.output_prefix}_length_distribution.png',
        f'{args.output_prefix}_length_distribution.pdf'
    ])
    
    # 保存每个序列的长度信息
    seq_lengths_df = pd.DataFrame([
        {'Sequence_ID': seq_id, 'Length': len(seq)}
        for seq_id, seq in sequences.items()
    ])
    
    seq_lengths_file = f'{args.output_prefix}_sequence_lengths.csv'
    seq_lengths_df.to_csv(seq_lengths_file, index=False)
    output_files.append(seq_lengths_file)
    
    # 生成总结报告
    with open(f'{args.output_prefix}_report.txt', 'w') as report:
        report.write("FASTA序列长度统计分析报告\n")
        report.write("="*50 + "\n")
        report.write(f"输入文件: {args.input_fasta}\n")
        report.write(f"分析时间: {pd.Timestamp.now()}\n\n")
        
        report.write("统计摘要:\n")
        report.write("-"*30 + "\n")
        for key, value in stats.items():
            if isinstance(value, float):
                report.write(f"{key}: {value:.2f}\n")
            else:
                report.write(f"{key}: {value}\n")
        
        report.write(f"\n生成了 {len(length_counts)} 个不同长度类别\n")
        report.write(f"输出文件: {', '.join(output_files)}\n")
    
    output_files.append(f'{args.output_prefix}_report.txt')
    
    print("\n" + "="*50)
    print("分析完成！生成的文件:")
    for file in output_files:
        print(f"  - {file}")
    
    # 打印长度分布预览
    print("\n长度分布预览 (前20个):")
    print("-"*40)
    print(f"{'长度':<10} {'数量':<10} {'百分比':<10}")
    print("-"*40)
    for i, (length, count) in enumerate(length_counts.items()):
        if i >= 20:
            break
        percentage = (count / stats['total_sequences']) * 100
        print(f"{length:<10} {count:<10} {percentage:.2f}%")
    
    if len(length_counts) > 20:
        print(f"... 还有 {len(length_counts) - 20} 个长度类别")

if __name__ == "__main__":
    main()
