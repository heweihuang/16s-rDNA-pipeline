#!/usr/bin/env Rscript
# 系统发育树可视化 - 优化版本

# 加载必要包
library(ggplot2)
library(ggtree)
library(colorspace)
library(dplyr)
library(ape)
library(treeio)
library(tidyr)
library(RColorBrewer)

# 设置参数
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 4) {
  table_file <- "table.from_0.001_fraction.txt"
  tree_file <- "rep_set_0.001_fraction.tre"
  circos_file <- "circosTree_optimized.pdf"
  heatmap_file <- "heatmapTree_optimized.pdf"
} else {
  table_file <- args[1]
  tree_file <- args[2]
  circos_file <- args[3]
  heatmap_file <- args[4]
}

# ==================== 数据读取和处理 ====================
# 读取OTU表格
rt <- read.table(table_file, sep = "\t", header = TRUE, skip = 1, 
                 row.names = 1, comment.char = "", stringsAsFactors = FALSE)

# 提取门水平信息
extract_phylum <- function(taxonomy) {
  if (is.na(taxonomy) || taxonomy == "") {
    return("Unknown")
  }
  parts <- strsplit(taxonomy, ";")[[1]]
  phylum_idx <- grep("p__", parts)
  if (length(phylum_idx) > 0) {
    phylum <- gsub("^[[:space:]]*p__", "", parts[phylum_idx[1]])
    phylum <- gsub("[[:space:]]*$", "", phylum)
    if (phylum == "") return("Unknown")
    return(phylum)
  }
  return("Unknown")
}

# 为每个OTU分配门
otu_phylum <- sapply(rt$taxonomy, extract_phylum)
names(otu_phylum) <- rownames(rt)

# 统计门信息
phylum_table <- table(otu_phylum)
phylum_names <- names(phylum_table)[order(phylum_table, decreasing = TRUE)]
phylum_num <- length(phylum_names)

# ==================== 优化颜色方案 ====================
set.seed(123)

# 创建优化颜色方案 - 避免浅色
generate_optimized_colors <- function(n) {
  if (n <= 12) {
    # 使用Set2和Set3混合，避免浅色
    colors1 <- brewer.pal(8, "Set2")
    colors2 <- brewer.pal(12, "Set3")
    colors <- c(colors1, colors2)
    
    # 移除浅黄色、浅绿色等
    light_colors <- c("#FFFFB3", "#FDB462", "#B3DE69", "#FCCDE5")
    colors <- colors[!colors %in% light_colors]
    
    # 如果颜色不够，添加深色
    if (n > length(colors)) {
      additional_colors <- sequential_hcl(n - length(colors), palette = "Dark 3")
      colors <- c(colors, additional_colors)
    }
    return(colors[1:n])
  } else {
    # 使用深色为主的调色板
    return(qualitative_hcl(n, palette = "Dark 3", 
                          alpha = 0.8, rev = FALSE))
  }
}

phylum_colors <- generate_optimized_colors(phylum_num)
names(phylum_colors) <- phylum_names

# 为"Unknown"分配灰色
phylum_colors["Unknown"] <- "#A0A0A0"

# ==================== 读取和处理树文件 ====================
tree <- read.tree(tree_file)

# 创建OTU到门的映射
tip_phylum <- setNames(rep("Unknown", Ntip(tree)), tree$tip.label)
common_otus <- intersect(names(otu_phylum), tree$tip.label)
for (otu in common_otus) {
  tip_phylum[otu] <- otu_phylum[otu]
}

# ==================== 创建分组 ====================
group_list <- list()
for (phylum in phylum_names) {
  tips_in_phylum <- names(tip_phylum)[tip_phylum == phylum]
  if (length(tips_in_phylum) > 0) {
    group_list[[phylum]] <- tips_in_phylum
  }
}

# 添加未分组
ungrouped_tips <- names(tip_phylum)[tip_phylum == "Unknown"]
if (length(ungrouped_tips) > 0) {
  group_list[["Unknown"]] <- ungrouped_tips
}

# 使用groupOTU
tree_grouped <- groupOTU(tree, group_list)

# ==================== 生成环形树（无背景高亮） ====================
pdf(circos_file, width = 14, height = 14)

# 获取所有组名
all_groups <- names(group_list)

# 创建颜色映射（包括Unknown）
all_colors <- phylum_colors[all_groups]
if ("Unknown" %in% all_groups) {
  all_colors["Unknown"] <- "#A0A0A0"
}

# 创建基础树图 - 直接通过分支线颜色显示
p <- ggtree(tree_grouped, layout = "fan", ladderize = FALSE, 
            branch.length = "none", size = 1.5, aes(color = group)) +
  scale_color_manual(
    name = "Phylum",
    values = all_colors,
    breaks = all_groups,
    labels = all_groups
  )

# 添加tip标签 - 放大字体
p <- p + geom_tiplab2(
  aes(label = gsub("\\d+\\.\\d+|New\\.|Reference|CleanUp\\.|\\.", "", label)),
  size = 3,  # 放大字体
  offset = 0.12,
  align = TRUE,
  linesize = 0.3,
  fontface = "bold"
)

# 优化图例位置 - 放在右侧中间，不重叠
p <- p + 
  theme(
    plot.title = element_text(hjust = 0.5, size = 20, face = "bold"),
    legend.position = c(1.05, 0.5),  # 右侧中间
    legend.background = element_rect(fill = "white", color = "black", size = 0.5),
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 11),
    legend.key.size = unit(0.8, "cm"),
    plot.margin = margin(30, 120, 30, 30)  # 右侧留更多空间给图例
  ) +
  guides(color = guide_legend(
    ncol = 1,  # 单列显示
    title.position = "top",
    title.hjust = 0.5,
    keywidth = 1.2,
    keyheight = 1.2
  ))

print(p)
dev.off()

# ==================== 生成热图树（无背景高亮） ====================
pdf(heatmap_file, width = 24, height = 30)

# 创建矩形布局的树
p_tree <- ggtree(tree_grouped, layout = "rectangular", ladderize = TRUE, 
                 branch.length = "none", size = 1.2, aes(color = group)) +
  scale_color_manual(
    name = "Phylum",
    values = all_colors,
    breaks = all_groups,
    labels = all_groups
  ) +
  theme_tree2()

# 添加tip标签 - 放大字体
p_tree <- p_tree + 
  geom_tiplab(
    aes(label = gsub("\\d+\\.\\d+|New\\.|Reference|CleanUp\\.|\\.", "", label)),
    size = 3.5,  # 放大字体
    offset = 0.15,
    align = TRUE,
    fontface = "bold"
  )

# 添加标题
p_tree <- p_tree + 
  theme(
    plot.title = element_text(hjust = 0.5, size = 22, face = "bold"),
    legend.position = "right",  # 右侧单列
    legend.title = element_text(size = 16, face = "bold"),
    legend.text = element_text(size = 13),
    legend.key.size = unit(1.0, "cm"),
  )

# 准备热图数据
heat_data <- rt[, 1:(ncol(rt) - 1), drop = FALSE]
heat_data <- as.matrix(heat_data)
heat_data <- heat_data[tree$tip.label, ]
heat_data_norm <- log10(heat_data + 1)

# 添加热图 - 样品名标签放在底部
p_combined <- gheatmap(
  p_tree,
  heat_data_norm,
  offset = 0.08,
  width = 1.8,
  colnames = TRUE,
  colnames_position = "bottom",  # 将样品名标签放在底部
  colnames_angle = 45,
  colnames_offset_y = -0.5,      # 负值使标签向下移动，确保完全显示
  colnames_offset_x = 0,
  font.size = 4.0,
  hjust = 1
) +
  scale_fill_gradientn(
    name = "Log10(Abundance+1)",
    colors = c("#053061", "#2166AC", "#4393C3", "#92C5DE", 
               "#D1E5F0", "#F7F7F7", "#FDDBC7", "#F4A582", 
               "#D6604D", "#B2182B", "#67001F"),
    na.value = "grey90",
    guide = guide_colorbar(
      title.position = "top",
      barwidth = 18,
      barheight = 1.0,
      title.theme = element_text(size = 12),  # 图例标题字体
      label.theme = element_text(size = 5)    # 图例刻度标签字体变小，避免重叠
    )
  ) +
  theme(
    legend.box = "vertical",
    legend.box.just = "left",
    legend.spacing.y = unit(0.5, "cm"),
    axis.text.y = element_text(size = 2),  # 仅保留左侧OTU标签
    axis.text.x = element_blank(),         # 删除下方刻度标签
    axis.ticks.x = element_blank(),        # 删除下方刻度线
    axis.line.x = element_blank(),         # 删除X轴线（最下方的实线）
    panel.border = element_blank(),        # 删除面板边框
    plot.margin = margin(20, 40, 60, 20)   # 调整边距：增大底部边距确保样品名显示
  ) +
  coord_cartesian(clip = "off")            # 允许图形元素超出绘图区域

print(p_combined)
dev.off()

# ==================== 生成统计报告CSV ====================
stats_df <- data.frame(
  Phylum = all_groups,
  OTUs_in_Table = sapply(all_groups, function(p) {
    if (p == "Unknown") return(length(ungrouped_tips))
    if (p %in% names(phylum_table)) return(phylum_table[p])
    return(0)
  }),
  OTUs_in_Tree = sapply(all_groups, function(p) sum(tip_phylum == p, na.rm = TRUE)),
  Percentage = sapply(all_groups, function(p) {
    if (p == "Unknown") {
      return(round(length(ungrouped_tips) / nrow(rt) * 100, 2))
    }
    if (p %in% names(phylum_table)) {
      return(round(phylum_table[p] / nrow(rt) * 100, 2))
    }
    return(0)
  }),
  Color_Hex = all_colors[all_groups],
  stringsAsFactors = FALSE
)

write.csv(stats_df, "Phylum_Statistics_Optimized.csv", row.names = FALSE)

