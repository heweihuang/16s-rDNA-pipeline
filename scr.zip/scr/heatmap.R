# 加载必要的包
library('gplots')

# 检查是否通过命令行传递参数
if (!interactive() && length(commandArgs(trailingOnly = TRUE)) >= 3) {
  # 命令行模式
  args <- commandArgs(trailingOnly = TRUE)
  input_file <- args[1]
  output_file <- args[2]
  lineNum <- as.numeric(args[3])
} else {
  # 交互式模式（保持原脚本行为）
  input_file <- "otus/table.from_biom_w_taxonomy.txt"
  output_file <- "heatmap.pdf"
  lineNum <- 100
}

# 读取数据
rt <- read.table(input_file, sep="\t", header=TRUE, skip=1, 
                 row.names=1, comment.char = "")

# 去除分类信息列，只保留样本数据
sampleNum <- ncol(rt) - 1
rt <- rt[, 1:sampleNum]

# 按行和排序，取top N
rt1 <- rt[order(rowSums(rt), decreasing=TRUE), ]
rt2 <- rt1[1:lineNum, ]

# 对数据进行log10转换（+1避免log10(0)）
y <- as.matrix(log10(rt2 + 1))

# 生成热图
pdf(file=output_file, height=12)
par(oma=c(3, 3, 3, 5))
heatmap.2(y, col='greenred', trace="none", cexCol=1)
dev.off()
